package com.example.model;

public enum Gender {
MALE,
FEMALE
}
