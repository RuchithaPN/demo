 export class User {
    id: number;
    age: number;
    gender: string;
    height: number;
    weight: number;
    activityLevel: string;
    bmr: number;
    dailyCalorieNeeds: number;
   
  }
  