export class Salary {
    id: number;
    salary: number;
    hRA: number;
    lTA: number;
    sA: number;
    grossSalary: number;
    deduction: number;
    netSalary: number;
    taxAmount: number;
    tax: number;
    taxPayable: number;
    taxLiability: number;
    cess: number;
    surCharge: number;
    age: number;

}